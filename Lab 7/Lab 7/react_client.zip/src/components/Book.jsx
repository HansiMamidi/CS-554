import React, {useState} from 'react';
import './App.css';
import {useQuery} from '@apollo/client';
import { useParams } from 'react-router-dom';
import queries from '../queries';
import Add from './Add';
import DeleteBookModal from './DeleteBookModal';
import EditBookModal from './EditBookModal';

function Book() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editBook, setEditBook] = useState(null);
  const [deleteBook, setDeleteBook] = useState(null);
  console.log("book");

  const { id } = useParams();
  console.log("bookId from URL:", id);

  const { loading, error, data } = useQuery(queries.GET_BOOK_BY_ID, {
    variables: { id },
    fetchPolicy: 'cache-and-network',
  });

  const handleOpenEditModal = (book) => {
    setShowEditModal(true);
    setEditBook(book);
  };

  const handleOpenDeleteModal = (book) => {
    setShowDeleteModal(true);
    setDeleteBook(book);
  };

  const closeAddFormState = () => {
    setShowAddForm(false);
  };

  const handleCloseModals = () => {
    setShowEditModal(false);
    setShowDeleteModal(false);
  };

  if (data) {
    const  book  = data.getBookById;
    console.log(book)
    // console.log(data.getBookById, "book", book);

    return (
      <div>
        {showAddForm && <Add type='book' closeAddFormState={closeAddFormState} />}
        <br />
        <br />

        <div className='card' key={book._id}>
          <div className='card-body'>
          <h5 className='card-title'>
                  Title: {book.title} 
                </h5>
                {/* <h5 className='card-title'>
                  Genres: {book.genres} 
                </h5> */}
                <h5>Genres: </h5>
                    {book.genres.map((genre) => {
                      return (
                        <h5>
                          {genre} 
                        </h5>
                      );
                    })}
                <h5 className='card-title'>
                  Publication Date: {book.publicationDate} 
                </h5>
                <h5 className='card-title'>
                  Publisher: {book.publisher} 
                </h5>
                <h5 className='card-title'>
                  Summary: {book.summary} 
                </h5>
                <h5 className='card-title'>
                  isbn: {book.isbn} 
                </h5>
                <h5 className='card-title'>
                  Language: {book.language} 
                </h5>
                <h5 className='card-title'>
                  Page Count: {book.pageCount} 
                </h5>
                <h5 className='card-title'>
                  Price: {book.price} 
                </h5>
                <h5 className='card-title'>
                  Format: {book.format} 
                </h5>
                <h5 className='card-title'>
                  Author: {book.author.first_name} {book.author.last_name}
                </h5>

                
                <br />
          </div>
        </div>

        <button
          className='button'
          onClick={() => {
            handleOpenEditModal(book);
          }}
        >
          Edit
        </button>
        <button
          className='button'
          onClick={() => {
            handleOpenDeleteModal(book);
          }}
        >
          Delete
        </button>

        {showEditModal && (
          <EditBookModal
            isOpen={showEditModal}
            book={editBook}
            handleClose={handleCloseModals}
          />
        )}

        {showDeleteModal && (
          <DeleteBookModal
            isOpen={showDeleteModal}
            handleClose={handleCloseModals}
            deleteBook={deleteBook}
          />
        )}
      </div>
    );
  } else if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div>{error.message}</div>;
  }
}

export default Book;
