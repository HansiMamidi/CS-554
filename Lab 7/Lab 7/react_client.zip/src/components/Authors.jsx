import React, {useState} from 'react';
import './App.css';
import {useQuery} from '@apollo/client';
import {Link} from 'react-router-dom';
import queries from '../queries';
import Add from './Add';
import DeleteAuthorModal from './DeleteAuthorModal';
import EditAuthorModal from './EditAuthorModal';

function Authors() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editAuthor, setEditAuthor] = useState(null);
  const [deleteAuthor, setDeleteAuthor] = useState(null);
  const closeAddFormState = () => {
    setShowAddForm(false);
  };
  const {loading, error, data} = useQuery(
    queries.GET_AUTHORS_WITH_BOOKS,
    {
      fetchPolicy: 'cache-and-network'
    }
  );

  const handleOpenEditModal = (author) => {
    setShowEditModal(true);
    setEditAuthor(author);
  };

  const handleOpenDeleteModal = (author) => {
    setShowDeleteModal(true);
    setDeleteAuthor(author);
  };

  const handleCloseModals = () => {
    setShowEditModal(false);
    setShowDeleteModal(false);
  };

  if (data) {
    const {authors} = data;

    return (
      <div>
        <button className='button' onClick={() => setShowAddForm(!showAddForm)}>
          Create Author
        </button>
        {showAddForm && (
          <Add type='author' closeAddFormState={closeAddFormState} />
        )}
        <br />
        <br />
        <div>
          {authors.map((author) => {
            return (
              <div className='card' key={author._id}>
                <div className='card-body'>
                <Link to={`/authors/${author._id}`}>
                <h5 className='card-title'>
                  {author.first_name} {author.last_name}
                </h5>
                </Link>
                    <h5 className='card-title'>Date of Birth: {author.date_of_birth}</h5>
                  <h5 className='card-title'>Hometown City: {author.hometownCity}</h5>
                  <h5 className='card-title'>Hoemtown State: {author.hometownState}</h5>
                  <span>Number of Books:</span> {author.numOfBooks}
                  <br />
                  <br />
                  <span>Books:</span>
                  <br />
                  <ol>
                    {author.books.slice(0,3).map((book) => {
                      return (
                        <li key={book._id}>
                          {book.title} 
                        </li>
                      );
                    })}
                  </ol>
                  <br />
                <button
                  className='button'
                  onClick={() => {
                    handleOpenEditModal(author);
                  }}
                >
                  Edit
                </button>
                <button
                  className='button'
                  onClick={() => {
                    handleOpenDeleteModal(author);
                  }}
                >
                  Delete
                </button>

                </div>
              </div>
            );
          })}
          {showEditModal && (
            <EditAuthorModal
              isOpen={showEditModal}
              author={editAuthor}
              handleClose={handleCloseModals}
            />
          )}

          {showDeleteModal && (
            <DeleteAuthorModal
              isOpen={showDeleteModal}
              handleClose={handleCloseModals}
              deleteAuthor={deleteAuthor}
            />
          )}
        </div>
      </div>
    );
  } else if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div>{error.message}</div>;
  }
}

export default Authors;
