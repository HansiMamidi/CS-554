import React, { useState } from 'react';
import './App.css';
import ReactModal from 'react-modal';
import { useQuery, useMutation } from '@apollo/client';
import queries from '../queries';

ReactModal.setAppElement('#root');
const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    width: '50%',
    border: '1px solid #28547a',
    borderRadius: '4px',
  },
};

function EditBookModal(props) {
  const [showEditModal, setShowEditModal] = useState(props.isOpen);
  const [book, setBook] = useState(props.book);
  const { loading, error, data } = useQuery(queries.GET_AUTHORS);
  const [editBook] = useMutation(queries.EDIT_BOOK);

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setBook(null);
    props.handleClose();
  };

  let title;
  let genres;
  let publicationDate;
  let publisher;
  let summary;
  let isbn;
  let language;
  let pageCount;
  let price;
  let format;
  let authorId;

  if (data) {
    var { authors } = data;
  }

  if (loading) {
    return <div>loading...</div>;
  }

  const handleUpdateBook = (e) => {
    e.preventDefault();
    // console.log("book id",props.book._id)
    //         console.log(title.value, "isbn", isbn.value);
    //         console.log(genres.value, "isbn", publicationDate.value);
    //         console.log(publisher.value, "isbn", summary.value);
    //         console.log(language.value, "isbn", pageCount.value);
    //         console.log(price.value, "isbn", format.value);
            // console.log(authorId.value,typeof(authorId.value));
    editBook({
      variables: {
        id: props.book._id,
        title: title.value,
        genres: genres.value,
        publicationDate: publicationDate.value,
        publisher: publisher.value,
        summary: summary.value,
        isbn: isbn.value,
        language: language.value,
        pageCount: parseInt(pageCount.value),
        price: parseFloat(price.value),
        format: format.value,
        authorId: authorId.value,
      },
    })
      .then(() => {
        setBook({
          title: '',
          genres: '',
          publicationDate: '',
          publisher: '',
          summary: '',
          isbn: '',
          language: '',
          pageCount: '',
          price: '',
          format: '',
          authorId: '',
        })
        
        setShowEditModal(false);

        alert('Book Updated');
        props.handleClose();
      })
      .catch((error) => {
        alert(`Error: ${error.networkError.result.errors[0].message}`);
      });
  };

  return (
    <div>
      <ReactModal
        name='editModal'
        isOpen={showEditModal}
        contentLabel='Edit Book'
        style={customStyles}
      >
        <form className='form' id='add-book' onSubmit={handleUpdateBook}>
          <div className='form-group'>
            <label>
              Title:
              <br />
              <input
                ref={(node) => {
                  title = node;
                }}
                defaultValue={book.title}
                autoFocus={true}
              />
            </label>
          </div>
          <br />
          <label>
              Genres:
              <br />
              <input
                ref={(node) => {
                  genres = node;
                }}
                defaultValue={book.genres}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
              Publication Date:
              <br />
              <input
                ref={(node) => {
                  publicationDate = node;
                }}
                defaultValue={book.publicationDate}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
            Publisher:
              <br />
              <input
                ref={(node) => {
                  publisher = node;
                }}
                defaultValue={book.publisher}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
              Summary:
              <br />
              <input
                ref={(node) => {
                  summary = node;
                }}
                defaultValue={book.summary}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
            isbn:
              <br />
              <input
                ref={(node) => {
                  isbn = node;
                }}
                defaultValue={book.isbn}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
            Language:
              <br />
              <input
                ref={(node) => {
                  language = node;
                }}
                defaultValue={book.language}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
            Page Count:
              <br />
              <input
                ref={(node) => {
                  pageCount = node;
                }}
                defaultValue={book.pageCount}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
            Price:
              <br />
              <input
                ref={(node) => {
                  price = node;
                }}
                defaultValue={book.price}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
              Format:
              <br />
              <input
                ref={(node) => {
                  format = node;
                }}
                defaultValue={book.format}
                autoFocus={true}
              />
            </label>
          <div className='form-group'>
            <label>
              Author:
              <select
                defaultValue={book.author._id}
                className='form-control'
                ref={(node) => {
                  authorId = node;
                }}
              >
                {authors &&
                  authors.map((author) => {
                    return (
                      <option key={author._id} value={author._id}>
                        {author.first_name}
                      </option>
                    );
                  })}
              </select>
            </label>
          </div>
          <br />
          <br />
          <button className='button add-button' type='submit'>
            Update Book
          </button>
        </form>

        <button className='button cancel-button' onClick={handleCloseEditModal}>
          Cancel
        </button>
      </ReactModal>
    </div>
  );
}

export default EditBookModal;
