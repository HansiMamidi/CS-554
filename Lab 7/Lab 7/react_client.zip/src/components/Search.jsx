import React, { useState, useEffect } from 'react';
import { useLazyQuery } from '@apollo/client';
import queries from '../queries';

function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [min, setMin] = useState(0);
  const [max, setMax] = useState(0);
  const [searchValue, setSearchValue] = useState("");
  const [queryResult, setQueryResult] = useState(null);

  const [selectedQuery, { loading, error, data }] = useLazyQuery(
    queries.SEARCH_BOOKS_BY_GENRE,
    {
      fetchPolicy: 'cache-and-network',
    }
  );

  useEffect(() => {
    if (!loading && data) {
      setQueryResult(data);
    }
    if (error) {
      alert(`Error: ${error.message}`);
    }
  }, [loading, data, error]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const query =
      searchQuery === "SEARCH_BOOKS_BY_GENRE"
        ? queries.SEARCH_BOOKS_BY_GENRE
        : searchQuery === "SEARCH_BOOKS_BY_PRICE"
        ? queries.SEARCH_BOOKS_BY_PRICE
        : searchQuery === "SEARCH_AUTHORS_BY_NAME"
        ? queries.SEARCH_AUTHORS_BY_NAME
        : null;

    if (query) {
      selectedQuery({
        query,
        variables: {
          genre: searchQuery === "SEARCH_BOOKS_BY_GENRE" ? searchValue : null,
          min: searchQuery === "SEARCH_BOOKS_BY_PRICE" ? parseFloat(min) : null,
          max: searchQuery === "SEARCH_BOOKS_BY_PRICE" ? parseFloat(max) : null,
          searchTerm: searchQuery === "SEARCH_AUTHORS_BY_NAME" ? searchValue: null,
        },
      });
    } else {
      alert("Please fill in all the required details");
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <br />
        <br />
        <br />
        <label>
          Search By:
          <select value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}>
            <option value="">Select Search By option</option>
            <option value="SEARCH_BOOKS_BY_GENRE">Search Books by Genre</option>
            <option value="SEARCH_BOOKS_BY_PRICE">Search Books by Price</option>
            <option value="SEARCH_AUTHORS_BY_NAME">Search Authors by Name</option>
          </select>
        </label>
        {searchQuery === "SEARCH_BOOKS_BY_PRICE" ? (
          <div>
            <label>
              Min Price:
              <input
                type="number"
                value={min}
                onChange={(e) => setMin(parseFloat(e.target.value))}
              />
            </label>
            <label>
              Max Price:
              <input
                type="number"
                value={max}
                onChange={(e) => setMax(parseFloat(e.target.value))}
              />
            </label>
          </div>
        ) : (
          <label>
            Search Value:
            <input
              type="text"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
            />
          </label>
        )}

        <button type="submit">Search</button>
      </form>

      {loading && <div>Loading</div>}
      {!loading && data && (
        <div>
          {searchQuery === "SEARCH_BOOKS_BY_GENRE" && data.booksByGenre &&
            data.booksByGenre.map((result) => (
              <div className="card" key={result._id}>
                <div className="card-body">
                  <h5 className="card-title">Title: {result.title}</h5>
                  <div>
                    <h5>Genres: </h5>
                    {result.genres.map((genre) => (
                      <h5 className="card-title" key={genre}>{genre}</h5>
                    ))}
                  </div>

                  <br />
                  <br />
                </div>
              </div>
            ))}
          {searchQuery === "SEARCH_BOOKS_BY_PRICE" && data.booksByPriceRange &&
            data.booksByPriceRange.map((result) => (
              <div className="card" key={result._id}>
                <div className="card-body">
                  <h5 className="card-title">Title: {result.title}</h5>
                  <h5 className="card-title">Price: {result.price}</h5>
                  {/* <div>
                    <h5>Genres: </h5>
                    {result.genres.map((genre) => (
                      <li className="card-title" key={genre}>{genre}</li>
                    ))}
                  </div> */}
                  <br />
                  <br />
                </div>
              </div>
            ))}
          {searchQuery === "SEARCH_AUTHORS_BY_NAME" && data.searchAuthorsByName &&
            data.searchAuthorsByName.map((result) => (
              <div className="card" key={result._id}>
                <div className="card-body">
                  <h5 className="card-title">
                    Name: {result.first_name} {result.last_name}
                  </h5>
                  {/* <h5 className="card-title">{result._id}</h5> */}
                  <h5 className="card-title">Hometown City & State: {`${result.hometownCity}, ${result.hometownState}`}</h5>
                  <br />
                  <br />
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}

export default Search;
