import React, {useState} from 'react';
import './App.css';
import {useQuery} from '@apollo/client';
import { useParams } from 'react-router-dom';
import queries from '../queries';
import Add from './Add';
import DeleteAuthorModal from './DeleteAuthorModal';
import EditAuthorModal from './EditAuthorModal';

function Author() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editAuthor, setEditAuthor] = useState(null);
  const [deleteAuthor, setDeleteAuthor] = useState(null);
  console.log("author");

  const { id } = useParams();
  console.log("authorId from URL:", id);

  const { loading, error, data } = useQuery(queries.GET_AUTHOR_BY_ID, {
    variables: { id },
    fetchPolicy: 'cache-and-network',
  });

  const handleOpenEditModal = (author) => {
    setShowEditModal(true);
    setEditAuthor(author);
  };

  const handleOpenDeleteModal = (author) => {
    setShowDeleteModal(true);
    setDeleteAuthor(author);
  };

  const closeAddFormState = () => {
    setShowAddForm(false);
  };

  const handleCloseModals = () => {
    setShowEditModal(false);
    setShowDeleteModal(false);
  };

  if (data) {
    const  author  = data.getAuthorById;
    console.log(data.getAuthorById, "author", author);

    return (
      <div>
        {showAddForm && <Add type='book' closeAddFormState={closeAddFormState} />}
        <br />
        <br />

        <div className='card' key={author._id}>
          <div className='card-body'>
          <h5 className='card-title'>
                  Name: {author.first_name} {author.last_name} 
                </h5>
                <h5 className='card-title'>
                  Date of Birth: {author.date_of_birth} 
                </h5>
                <h5 className='card-title'>
                  Hometown City: {author.hometownCity} 
                </h5>
                <h5 className='card-title'>
                  Hometown State: {author.hometownState} 
                </h5>
                <span>Number of Books:</span> {author.numOfBooks}
                  <br />
                  <br />
                  <span>Books:</span>
                  <br />
                  <ol>
                    {author.books.slice(0,3).map((book) => {
                      return (
                        <li key={book._id}>
                          {book.title} {book.genres}
                        </li>
                      );
                    })}
                  </ol>
                <br />
          </div>
        </div>

        <button
          className='button'
          onClick={() => {
            handleOpenEditModal(author);
          }}
        >
          Edit
        </button>
        <button
          className='button'
          onClick={() => {
            handleOpenDeleteModal(author);
          }}
        >
          Delete
        </button>

        {showEditModal && (
          <EditAuthorModal
            isOpen={showEditModal}
            author={editAuthor}
            handleClose={handleCloseModals}
          />
        )}

        {showDeleteModal && (
          <DeleteAuthorModal
            isOpen={showDeleteModal}
            handleClose={handleCloseModals}
            deleteAuthor={deleteAuthor}
          />
        )}
      </div>
    );
  } else if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div>{error.message}</div>;
  }
}

export default Author;
