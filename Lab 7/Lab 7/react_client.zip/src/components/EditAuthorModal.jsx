import React, { useEffect, useState } from 'react';
import './App.css';
import ReactModal from 'react-modal';
import { useQuery, useMutation } from '@apollo/client';
import queries from '../queries';

ReactModal.setAppElement('#root');
const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    width: '50%',
    border: '1px solid #28547a',
    borderRadius: '4px',
  },
};

function EditAuthorModal(props) {
  const [showEditModal, setShowEditModal] = useState(props.isOpen);
  const [author, setAuthor] = useState(props.author);
  const { loading, data } = useQuery(queries.GET_AUTHORS);
  const [editAuthor] = useMutation(queries.EDIT_AUTHOR);

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setAuthor(null);
    props.handleClose();
  };

  const handleInputChange = (e) => {
    setAuthor({ ...author, [e.target.name]: e.target.value });
  };

  if (loading) {
    return <div>loading...</div>;
  }

  return (
    <div>
      <ReactModal name='editModal' isOpen={showEditModal} contentLabel='Edit Author' style={customStyles}>
        <form
          className='form'
          id='add-author'
          onSubmit={(e) => {
            e.preventDefault();
            editAuthor({
              variables: {
                id: props.author._id,
                ...author,
              },
            })
              .then(() => {
                setAuthor({
                  first_name: '',
                  last_name: '',
                  date_of_birth: '',
                  hometownCity: '',
                  hometownState: '',
                });
                setShowEditModal(false);
                alert('Author Updated');
                props.handleClose();
              })
              .catch((error) => {
                console.log("error",error)
                alert(`Error: ${error.networkError.result.errors[0].message}`);
                
              });
          }}
        >
          <div className='form-group'>
            <label>
              First Name:
              <br />
              <input
                type='text'
                name='first_name'
                value={author.first_name}
                onChange={handleInputChange}
                autoFocus={true}
              />
            </label>
            <br/>
            <label>
              Last Name:
              <br />
              <input
                type='text'
                name='last_name'
                value={author.last_name}
                onChange={handleInputChange}
              />
            </label>
            <br/>
            <label>
              Date of Birth:
              <br />
              <input
                type='text'
                name='date_of_birth'
                value={author.date_of_birth}
                onChange={handleInputChange}
              />
            </label>
            <br/>
            <label>
              Hometown City:
              <br />
              <input
                type='text'
                name='hometownCity'
                value={author.hometownCity}
                onChange={handleInputChange}
              />
            </label>
            <br/>
            <label>
              Hometown State:
              <br />
              <input
                type='text'
                name='hometownState'
                value={author.hometownState}
                onChange={handleInputChange}
              />
            </label>
            
          </div>
          <br />
          <br />
          <button className='button add-button' type='submit'>
            Update Author
          </button>
        </form>

        <button className='button cancel-button' onClick={handleCloseEditModal}>
          Cancel
        </button>
      </ReactModal>
    </div>
  );
}

export default EditAuthorModal;
