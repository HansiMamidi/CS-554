import React from 'react';
import './App.css';
import {useQuery, useMutation} from '@apollo/client';
import queries from '../queries';

function Add(props) {
  const [addBook] = useMutation(queries.ADD_BOOK, {
    update(cache, {data: {addBook}}) {
      const {books} = cache.readQuery({
        query: queries.GET_BOOKS
      });
      cache.writeQuery({
        query: queries.GET_BOOKS,
        data: {books: [...books, addBook]}
      });
    },
    // onError: (error) => {
    //   alert(`Error adding book: ${error.message}`);
    // },  
  });

  const [addAuthor, { loading, error }] = useMutation(queries.ADD_AUTHOR, {
    update(cache, {data: {addAuthor}}) {
      const {authors} = cache.readQuery({
        query: queries.GET_AUTHORS_WITH_BOOKS
      });
      cache.writeQuery({
        query: queries.GET_AUTHORS_WITH_BOOKS,
        data: {authors: [...authors, addAuthor]}
      });
    },
    // onError: (error) => {
    //   alert(`Error adding author: ${error.message}`);
    // },
  });

  // if (error) {
  //   alert(`Error: ${error.message}`);
  // }
  const onSubmitBook = (e) => {
    e.preventDefault();
    let title = document.getElementById('title');
    let genres = document.getElementById('genres');
    let publicationDate = document.getElementById('publicationDate');
    let publisher = document.getElementById('publisher');
    let summary = document.getElementById('summary');
    let isbn = document.getElementById('isbn');
    let language = document.getElementById('language');
    let pageCount = document.getElementById('pageCount');
    let price = document.getElementById('price');
    let format = document.getElementById('format');
  
    let authorId = document.getElementById('authorId');
    console.log(title.value, authorId.value);
    addBook({
      variables: {
        authorId: authorId.value,
        title: title.value,
        genres: genres.value,
        publicationDate: publicationDate.value,
        publisher: publisher.value,
        summary: summary.value,
        isbn: isbn.value,
        language: language.value,
        pageCount: parseInt(pageCount.value),
        price: parseFloat(price.value),
        format: format.value,
      },
    })
      .then(() => {
        authorId.value = '1';
        document.getElementById('add-book').reset();
        alert('Book Added');
        props.closeAddFormState();
      })
      .catch((error) => {
        // console.error('GraphQL Error:', error.message);
        alert(`Error: ${error.networkError.result.errors[0].message}`);
      });
  };
  

  const onSubmitAuthor = (e) => {
    e.preventDefault();
    let first_name = document.getElementById('first_name');
    let last_name = document.getElementById('last_name');
    let date_of_birth = document.getElementById('date_of_birth');
    let hometownCity = document.getElementById('hometownCity');
    let hometownState = document.getElementById('hometownState');
  
    addAuthor({
      variables: {
        first_name: first_name.value,
        last_name: last_name.value,
        date_of_birth: date_of_birth.value,
        hometownCity: hometownCity.value,
        hometownState: hometownState.value
      }
    })
    .then(() => {
      document.getElementById('add-author').reset();
      alert('Author Added');
      props.closeAddFormState();
    })
    .catch((error) => {
      // console.error("GraphQL Error:", error.message);
      alert(`Error: ${error.networkError.result.errors[0].message}`);
    });
  
    
  };
  
  const {data} = useQuery(queries.GET_AUTHORS);

  if (data) {
    var {authors} = data;
  }
  let body = null;
  if (props.type === 'book') {
    // console.log("book")
    body = (
      <div className='card'>
        <form className='form' id='add-book' onSubmit={onSubmitBook}>
          <div className='form-group'>
            <label>
              Title:
              <br />
              <input id='title' required autoFocus={true} />
            </label>
            <br/>
            <label>
              Genre:
              <br />
              <input id='genres' required autoFocus={true} />
            </label>
            <br/>
            <label>
              Publication Date:
              <br />
              <input id='publicationDate' required autoFocus={true} />
            </label>
            <br/>
            <label>
            Publisher:
              <br />
              <input id='publisher' required autoFocus={true} />
            </label>
            <br/>
            <label>
            Summary:
              <br />
              <input id='summary' required autoFocus={true} />
            </label>
            <br/>
            <label>
            isbn:
              <br />
              <input id='isbn' required autoFocus={true} />
            </label>
            <br/>
            <label>
            Language:
              <br />
              <input id='language' required autoFocus={true} />
            </label>
            <br/>
            <label>
            Page Count:
              <br />
              <input id='pageCount' required autoFocus={true} />
            </label>
            <br/>
            <label>
            Price:
              <br />
              <input id='price' required autoFocus={true} />
            </label>
            <br/>
            <label>
            Format:
              <br />
              <input id='format' required autoFocus={true} />
            </label>

          </div>
          <br />
          {/* <div className='form-group'>
            <label>
              Last Name:
              <br />
              <input id='lastName' required />
            </label>
          </div>
          <br /> */}

          <div className='form-group'>
            <label>
              Author:
              <select className='form-control' id='authorId'>
                {authors &&
                  authors.map((author) => {
                    return (
                      <option key={author._id} value={author._id}>
                        {author.first_name}
                      </option>
                    );
                  })}
              </select>
            </label>
          </div>

          <br />
          <br />
          <button className='button add-button' type='submit'>
            Add Book
          </button>
          <button
            type='button'
            className='button cancel-button'
            onClick={() => {
              document.getElementById('add-book').reset();
              props.closeAddFormState();
            }}
          >
            Cancel
          </button>
        </form>
      </div>
    );
  } else if (props.type === 'author') {
    body = (
      <div className='card'>
        <form className='form' id='add-author' onSubmit={onSubmitAuthor}>
          <div className='form-group'>
            <label>
              First Name:
              <br />
              <input id='first_name' required autoFocus={true} />
            </label>
            <br/>
            <label>
              Last Name:
              <br />
              <input id='last_name' required autoFocus={true} />
            </label>
            <br/>
            <label>
              Date of Birth:
              <br />
              <input id='date_of_birth' required autoFocus={true} />
            </label>
            <br/>
            <label>
              Hometown City:
              <br />
              <input id='hometownCity' required autoFocus={true} />
            </label>
            <br/>
            <label>
              Hometown State:
              <br />
              <input id='hometownState' required autoFocus={true} />
            </label>
            <br/>
          </div>
          <br />

          <br />
          <br />
          <button className='button' type='submit'>
            Add Author
          </button>
          <button
            type='button'
            className='button'
            onClick={() => {
              document.getElementById('add-author').reset();
              props.closeAddFormState();
            }}
          >
            Cancel
          </button>
        </form>
      </div>
    );
  }
  return <div>{body}</div>;
}

export default Add;
