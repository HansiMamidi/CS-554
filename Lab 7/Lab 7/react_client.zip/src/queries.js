import {gql} from '@apollo/client';
console.log("app.jsx")

const GET_BOOKS = gql`
  query {
    books {
      _id
      title
      genres
      publicationDate
      publisher
      summary
      isbn
      language
      pageCount
      price
      format
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const GET_BOOK_BY_ID = gql`
  query GetBookById($id: String!){
    getBookById(_id: $id) {
      _id
      title
      genres
      publicationDate
      publisher
      summary
      isbn
      language
      pageCount
      price
      format
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const GET_AUTHOR_BY_ID = gql`
  query GetAuthorById($id: String!){
    getAuthorById(_id: $id) {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
      books {
        _id
        title
        genres
      }
    }
  }
`;

const GET_AUTHORS = gql`
  query {
    authors {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
    }
  }
`;

const GET_AUTHORS_WITH_BOOKS = gql`
  query {
    authors {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
      numOfBooks
      books {
        _id
        title
        genres
      }
    }
  }
`;

const ADD_BOOK = gql`
  mutation createBook(
    $title: String!
    $genres: [String!]!
    $publicationDate: String!
    $publisher: String!
    $summary: String!
    $isbn: String!
    $language: String!
    $pageCount: Int!
    $price: Float!
    $format: [String!]!
    $authorId: String!
  ) {
    addBook(
      title: $title
      genres: $genres
      publicationDate: $publicationDate
      publisher: $publisher
      summary: $summary
      isbn: $isbn
      language: $language
      pageCount: $pageCount
      price: $price
      format: $format
      authorId: $authorId
    ) {
      _id
      title
      genres
      publicationDate
      publisher
      summary
      isbn
      language
      pageCount
      price
      format
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const ADD_AUTHOR = gql`
  mutation createAuthor(
    $first_name: String!,
    $last_name: String!,
    $date_of_birth: String!,
    $hometownCity: String!,
    $hometownState: String!
    ) {
    addAuthor(
      first_name: $first_name,
      last_name: $last_name,
      date_of_birth: $date_of_birth,
      hometownCity: $hometownCity,
      hometownState: $hometownState
      ) {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
      numOfBooks
      books {
        _id
        title
        genres
      }
    }
  }
`;

const DELETE_BOOK = gql`
  mutation deleteBook($id: String!) {
    removeBook(_id: $id) {
      _id
      title
      genres
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const EDIT_BOOK = gql`
  mutation changeBook(
    $id: String!
    $title: String
    $genres: [String!]!
    $publicationDate: String!
    $publisher: String!
    $summary: String!
    $isbn: String!
    $language: String!
    $pageCount: Int!
    $price: Float!
    $format: [String!]!
    $authorId: String
  ) {
    editBook(
      _id: $id
      title: $title
      genres: $genres
      publicationDate: $publicationDate
      publisher: $publisher
      summary: $summary
      isbn: $isbn
      language: $language
      pageCount: $pageCount
      price: $price
      format: $format
      authorId: $authorId
    ) {
      _id
      title
      genres
      publicationDate
      publisher
      summary
      isbn
      language
      pageCount
      price
      format
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const EDIT_AUTHOR = gql`
  mutation changeAuthor(
    $id: String!
    $first_name: String
    $last_name: String
    $date_of_birth: String
    $hometownCity: String
    $hometownState: String
  ) {
    editAuthor(
      _id: $id,
      first_name: $first_name,
      last_name: $last_name,
      date_of_birth: $date_of_birth,
      hometownCity: $hometownCity,
      hometownState: $hometownState
    ) {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
      books {
        _id
        title
        genres
      }
    }
  }
`;

const DELETE_AUTHOR = gql`
  mutation deleteAuthor($id: String!) {
    removeAuthor(_id: $id) {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
      books {
        _id
        title
        genres
      }
    }
  }
`;

const SEARCH_BOOKS_BY_GENRE = gql`
  query SearchBooksByGenre($genre: String!){
    booksByGenre(genre: $genre) {
      _id
      title
      genres
      publicationDate
      publisher
      summary
      isbn
      language
      pageCount
      price
      format
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const SEARCH_BOOKS_BY_PRICE = gql`
  query SearchBooksByPrice($min: Float!, $max: Float!){
    booksByPriceRange(min: $min, max: $max) {
      _id
      title
      genres
      publicationDate
      publisher
      summary
      isbn
      language
      pageCount
      price
      format
      author {
        _id
        first_name
        last_name
      }
    }
  }
`;

const SEARCH_AUTHORS_BY_NAME = gql`
  query SearchAuthorByName($searchTerm: String!){
    searchAuthorsByName(searchTerm: $searchTerm) {
      _id
      first_name
      last_name
      date_of_birth
      hometownCity
      hometownState
      books {
        _id
        title
        genres
      }
    }
  }
`;

let exported = {
  ADD_BOOK,
  GET_BOOKS,
  GET_BOOK_BY_ID,
  GET_AUTHORS,
  GET_AUTHOR_BY_ID,
  DELETE_BOOK,
  GET_AUTHORS_WITH_BOOKS,
  ADD_AUTHOR,
  EDIT_BOOK,
  EDIT_AUTHOR,
  DELETE_AUTHOR,
  SEARCH_BOOKS_BY_GENRE,
  SEARCH_BOOKS_BY_PRICE,
  SEARCH_AUTHORS_BY_NAME
};

export default exported;
