import {Router} from 'express';
const router = Router();
import axios from 'axios';
import redis from 'redis';
import md5 from 'blueimp-md5';

const client = redis.createClient();
client.connect().then(() => {});

  router.get('/page/:pagenum', async (req, res) => {
    try{
      let sample = await client.ping()
      console.log(sample)
      console.log('Comic Page not cached');
      const publickey = 'a5b17578bd1319a7b215cf78d5c72fa0';
      const privatekey = 'ee3c457884ace462ddab178930e21e6d6df4e68e';
      const ts = new Date().getTime();
      const stringToHash = ts + privatekey + publickey;
      console.log("page num",req.params.pagenum,typeof(req.params.pagenum))
      const offset = (parseInt(req.params.pagenum)-1)*20
      console.log
      const hash = md5(stringToHash);
      const baseUrl = 'https://gateway.marvel.com:443/v1/public/comics';
      const url = baseUrl + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash + '&offset=' + offset;
      console.log(url)
      let {data} = await axios.get(url);
      let lists = data.data.results
      // console.log("lists",lists)

      await client.set(req.params.pagenum+'<-pagenum', JSON.stringify(lists));
      return res.status(200).json(lists)
          // return res.status(404).json({error: 'Comic with that id not found'})
  }catch (e) {
      let status = e[0] ? e[0] : 500;
      let message = e[1] ? e[1] : 'Internal Server Error';
      res.status(status).json({error: message});
    }
  });

  router.get('/:id', async (req, res) => {
    try{
        let sample = await client.ping()
        console.log("comic id route")
        console.log('Comic not cached');
        const publickey = 'a5b17578bd1319a7b215cf78d5c72fa0';
        const privatekey = 'ee3c457884ace462ddab178930e21e6d6df4e68e';
        const ts = new Date().getTime();
        const stringToHash = ts + privatekey + publickey;
        const hash = md5(stringToHash);
        const baseUrl = `https://gateway.marvel.com:443/v1/public/comics/${req.params.id}`;
        const url = baseUrl + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;
        console.log("before url")
        console.log(url)
        console.log("after url")
        let {data} = await axios.get(url);
        let lists = data.data.results
        await client.set(req.params.id+'<-comic', JSON.stringify(lists));

        // for(let i=0;i<lists.length;i++){
        //     if(lists[i].id.toString()===req.params.id){
        //                 let gotit = await client.set(req.params.id+'<-comic', JSON.stringify(lists[i]));
                        
        //                 return res.status(200).json(lists[i])
        //         }          
        //     }
        //     return res.status(404).json({error: 'Comic with that id not found'})
        return res.status(200).json(lists)
    }catch (e) {
        let status = e[0] ? e[0] : 500;
        let message = e[1] ? e[1] : 'Internal Server Error';
        res.status(status).json({error: message});
      }
  });

  export default router;