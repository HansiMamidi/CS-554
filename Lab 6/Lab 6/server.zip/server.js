// This file should set up the express server as shown in the lecture code

import express from 'express';
import cors from 'cors';
const app = express();
import configRoutes from './index.js';
import redis from 'redis'
const client = redis.createClient();
client.connect().then(() => {});

app.use(express.json());
app.use(cors());
// const corsOptions = {
//   origin: 'http://localhost:5173',
//   methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
//   credentials: true,  // enable set cookie
//   optionsSuccessStatus: 204,
// };

// app.use(cors(corsOptions));

app.use('/api/comics/page/:pagenum', async (req, res, next) => {
  //lets check to see if we have the show detail page for this show in cache
 
    let exists = await client.exists(req.params.pagenum+'<-pagenum');
    if (exists) {
      //if we do have it in cache, send the raw html from cache
      console.log('Comic Page in Cache');
      let showDetailPage = await client.get(req.params.pagenum+'<-pagenum');
      res.json(JSON.parse(showDetailPage));
    } else {
      next();      
    }
  
});

app.use('/api/comics/:id', async (req, res, next) => {
  //lets check to see if we have the show detail page for this show in cache
 
    let exists = await client.exists(req.params.id+'<-comic');
    if (exists) {
      //if we do have it in cache, send the raw html from cache
      console.log('Comic in Cache');
      let showDetailPage = await client.get(req.params.id+'<-comic');
      res.json(JSON.parse(showDetailPage));
    } else {
      next();      
    }
  
});

configRoutes(app);

app.listen(3000, () => {
  console.log("We've now got a server!");
  console.log('Your routes will be running on http://localhost:3000');
});