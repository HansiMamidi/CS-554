import axios from 'axios';

const allComics = (pagenum) => async (dispatch) => {
  try{
    console.log("actions")
    const data = await axios.get(`http://localhost:3000/api/comics/page/${pagenum}`);
    console.log("data",data.data)
    dispatch({
      type: 'ALL_COMICS',
      payload: data
    })
  }
  catch(e){
    console.log(e)
    dispatch({
      type: 'ALL_COMIC_FAILURE',
      payload:e.message,
    })
  }
};

const createSubCollection = (name) => ({
  type: 'CREATE_SUBCOLLECTION',
  payload: {
    name: name
  }
});

const deleteSubCollection = (id) => ({
  type: 'DELETE_SUBCOLLECTION',
  payload: {id: id}
});

const selectSubCollection = (id) => ({
  type: 'SELECT_SUBCOLLECTION',
  payload: {id: id}
});

const collectComic = (id, comic) => ({
  type: 'COLLECT_COMIC',
  payload: {
    id: id,
    comic: comic
  }
})

const giveUpComic = (id, comic) => ({
  type: 'GIVEUP_COMIC',
  payload: {
    id: id,
    comic: comic
  }
});

const getAllCollectedComics = (id) => ({
  type: 'GET_ALL_COLLECTED_COMICS',
  payload: { id },
});


export {allComics, getAllCollectedComics, createSubCollection, deleteSubCollection, selectSubCollection, collectComic, giveUpComic};
