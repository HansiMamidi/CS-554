import './App.css';
import {Route, Link, Routes} from 'react-router-dom';
import logo from './img/logo.png';
import Home from './components/Home';
import ComicList from './components/ComicList';
import Comic from './components/Comic';
import Collections from './components/Collections';
import Error from './components/Error';
import Error1 from './components/Error1';

function App() {
  console.log("Coming here into App")
  return (
    <div className='App'>
      <header className='App-header'>
        <img src={logo} className='App-logo' alt='logo' />
        <h1 className='App-title'>Welcome to the Marvel API</h1>
      </header>
      <br />
      <br />
      <Routes>
        <Route path='/' element={<Home />} />
        {/* <Route path='/collection/page/:page/*' element={<Error1 />} /> */}
        <Route path='/marvel-comics/page/:pagenum' element={<ComicList />} />
        <Route path='/marvel-comics/:id' element={<Comic />} />
        <Route path='/marvel-comics/collections' element={<Collections />} />
        <Route path='*' element={<h2>404: Page Not Found</h2>} /> 
        
        <Route path='/Error' element={<Error />} />  
        <Route path='/Error1' element={<Error1 />} />       
      </Routes>
    </div>
  );
};

export default App;
