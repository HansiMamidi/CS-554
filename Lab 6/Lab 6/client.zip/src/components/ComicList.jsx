import React, { useState, useEffect } from 'react';
import axios from 'axios';
import * as actions from '../actions';
import noImage from '../img/download.jpeg';
import { Grid, CardMedia, Card, CardContent, Typography } from '@mui/material';
import { Link, useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import '../App.css';

const ComicList = () => {
  const [loading, setLoading] = useState(true);
  const [alertShown, setAlertShown] = useState(false);
  let { pagenum } = useParams();
  const [currentPage, setCurrentPage] = useState(parseInt(pagenum));
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const comics = useSelector((state) => state.comics);
  const selectedSubId = useSelector((state) => state.collections);

  const validPage = new RegExp(/^[0-9]+$/)
  if(!validPage.test(pagenum)){
    navigate('/Error1')
  }

  useEffect(() => {
    const fetchData = async () => {
      try {
         dispatch(actions.allComics(pagenum));
        setLoading(false);
      } catch (error) {
        console.error('Error fetching comics:', error);
      }
    };

    fetchData();
  }, [dispatch, pagenum, currentPage]);

  const totalObjects = 58250;
  const totalPages = Math.ceil(totalObjects / 20);

  const previousPage = () => {
    currentPage > 1 && setCurrentPage(currentPage - 1);
    navigate(`/marvel-comics/page/${currentPage - 1}`);
  };

  const nextPage = () => {
    currentPage < totalPages && setCurrentPage(currentPage + 1);
    navigate(`/marvel-comics/page/${currentPage + 1}`);
  };

  const handleClick = (comic) => {
    if (comic.id) {
      navigate(`/marvel-comics/${comic.id}`);
    }
  };

  const handleCollect = (comic) => {
    // console.log('Dispatching COLLECT_COMIC action:', selectedSubId.selectedId, comic);

      const selectedSubCollection = selectedSubId.subCollections.find(
        (subCollection) => subCollection.id === selectedSubId.selectedId
      );

      if (selectedSubCollection && selectedSubCollection.comics.length < 20) {
         dispatch(actions.collectComic(selectedSubId, comic));
      } else {
        if (!alertShown) {
          alert('Cannot add more than 20 comics to the selected subcollection. Give up before Adding more');
          setAlertShown(true); 
        }
            }

    if(!alertShown){
      navigate(`/marvel-comics/${comic.id}`);

    }
    
  };
  

  const handleGiveUp = () => {
    // console.log('Dispatching GIVEUP_COMIC action:', selectedSubId.selectedId, comic);

    dispatch(actions.giveUpComic(selectedSubId, comic));
    navigate(`/marvel-comics/${comic.id}`);
  };

  // console.log("comics",comics.data, Array.isArray(comics.data))

  if(!loading && comics.data && (comics.data).length===0){
    navigate('/Error');
  }



  let cardsData =
    comics && comics.data
      ? comics.data.map((comic) => (
          <Grid item xs={12} sm={7} md={5} lg={4} xl={3} key={comic.id}>
            <Card
              variant='outlined'
              sx={{
                maxWidth: 250,
                color: '#a82a2e',
                height: 'auto',
                marginLeft: 'auto',
                marginRight: 'auto',
                borderRadius: 5,
                border: '1px solid #1e8678',
                boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);',
                '&:hover': {
                  cursor: 'pointer',
                },
              }}
              onClick={() => handleClick(comic)}
            >
              <CardContent>
              <CardMedia
                sx={{
                  height: '100%',
                  width: '100%',
                }}
                component='img'
                image={comic.images[0] ? `${(comic.images)[0].path.replace(/ /g, '_')}.jpg` : noImage}

                alt={comic && comic.title  ? comic.title: 'Comic Image Alt Text'}
              />
                <Typography
                  sx={{
                    borderBottom: '1px solid #1e8678',
                    fontWeight: 'bold',
                  }}
                  gutterBottom
                  variant='h6'
                  component='h3'
                >
                  {comic.id ? comic.id : 'N/A'}
                </Typography>
                <Typography
                  sx={{
                    borderBottom: '1px solid #1e8678',
                    fontWeight: 'bold',
                  }}
                  gutterBottom
                  variant='h6'
                  component='h3'
                >
                  {comic.title ? comic.title : 'N/A'}
                </Typography>
                {selectedSubId.selectedId && (
                  <>

                    {!selectedSubId.subCollections
                      .find(
                        (subCollection) =>
                          subCollection.id === selectedSubId.selectedId
                      )
                      .comics.some((collectedComic) => collectedComic.id === comic.id) && (
                      <button onClick={() => handleCollect(comic)}> Collect </button>
                    )}

                    {selectedSubId.subCollections
                      .find(
                        (subCollection) =>
                          subCollection.id === selectedSubId.selectedId
                      )
                      .comics.some((collectedComic) => collectedComic.id === comic.id) && (
                      <button onClick={() => handleGiveUp(comic)}> Give Up </button>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))
      : null;

  return (
    <div>
      {loading ? (
        <div>
          <h2>Loading....</h2>
        </div>
      ) : (
        <div>
          <br />
          <br />
          <Grid
            container
            spacing={2}
            sx={{
              flexGrow: 1,
              flexDirection: 'row',
            }}
          >
            <Link to='/marvel-comics/collections'>Show all Collections...</Link>
            {cardsData}
          </Grid>

          <div>
            <button onClick={previousPage} disabled={currentPage === 1}>
              Previous
            </button>
            {currentPage}
            <button onClick={nextPage} disabled={currentPage === totalPages}>
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComicList;
