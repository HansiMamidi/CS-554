import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {Link, useParams, useNavigate} from 'react-router-dom';
import '../App.css';
import * as actions from '../actions';
import { Grid, Card, CardContent, Typography } from '@mui/material';

const Collections = () => {
  const dispatch = useDispatch();
  const collectionsState = useSelector((state) => state.collections);
  const [newSubCollectionName, setNewSubCollectionName] = useState('');

  const handleAddSubCollection = () => {
    if (newSubCollectionName) {
      if(newSubCollectionName.length>40){
        alert("Sub-Collection name cannot be more than 40 characters long")
      }
      else{
        dispatch(actions.createSubCollection(newSubCollectionName));
      }
      
      setNewSubCollectionName(''); 
    }
  };

  // console.log('collection state:', collectionsState);

  return (
    <div>
      <h2>Collections</h2>

    <input
        type="text"
        value={newSubCollectionName}
        onChange={(e) => setNewSubCollectionName(e.target.value)}
        placeholder="Enter sub-collection name"
      />
      <button onClick={handleAddSubCollection}>Add Sub-Collection</button>
    
     
      <>
        {collectionsState &&
          collectionsState.subCollections &&
          collectionsState.subCollections.map((subCollection) => (
            <Card key={subCollection.id} variant="outlined"
            sx={{
              maxWidth: 550,
              height: 'auto',
              marginLeft: 'auto',
              marginRight: 'auto',
              borderRadius: 5,
              border: '1px solid #1e8678',
              boxShadow: '0 19px 38px rgba(0,0,0,0.30);',
              cursor: 'pointer',
            }}>

              
              <dl>
                <dt className="title">Collection Name:</dt>
                <dd>{subCollection.name}</dd>
              </dl>
              
              
              <div>
                {subCollection.comics.map((comic) => (
                  <div key={(comic.id || comic[0].id) ? (comic.id || comic[0].id) : null}>
                    <dl className='title'>
                      <dt className="title">Comic ID:</dt>
                      <dd>{(comic.id || comic[0].id) ? (comic.id || comic[0].id) : null}</dd>
                    </dl>

                    <dl className='title'>
                      <dt className="title">Comic Title:</dt>
                      <dd>{(comic.title || comic[0].title) ? (comic.title || comic[0].title) : null}</dd>
                    </dl>
                   <Link to={`/marvel-comics/${(comic.id || comic[0].id) ? (comic.id || comic[0].id) : null}`}>
                View Comic Details
              </Link><br/>
              <button onClick={() => dispatch(actions.giveUpComic(subCollection.id, comic || comic[0]))}>Give UP</button>
                  </div>
                ))}
                
              
              <button onClick={() => dispatch(actions.selectSubCollection(subCollection.id))}>
                Select
              </button>

              <button onClick={() => dispatch(actions.deleteSubCollection(subCollection.id))}>
                Delete
              </button>
              </div>
            </Card>
            
          ))}
      </>
      <Link to='/marvel-comics/page/1'>Show all Comics...</Link>
    </div>
  );
};

export default Collections;
