import React from 'react';
import { Link} from 'react-router-dom';

function Error() {
  return (
    <div>
      <h2>404:Page Not Found</h2>
      <Link to="/marvel-comics/page/1">Show all Comics...</Link>
      <Link to="/marvel-comics/collections">show all Collections...</Link>
    </div>
  );
}

export default Error;
