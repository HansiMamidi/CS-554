import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams, useNavigate } from 'react-router-dom';
import noImage from '../img/download.jpeg';
import { useSelector, useDispatch } from 'react-redux';
import * as actions from '../actions';

import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  CardHeader,
} from '@mui/material';
import '../App.css';

const Comic = () => {
  let { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const selectedSubId = useSelector((state) => state.collections);
  const [alertShown, setAlertShown] = useState(false);

  const validId = new RegExp(/^[1-9]\d*$/);
  if(!validId.test(id)){
    navigate('/Error1')
  }

 console.log("selector data comic.jsx", selectedSubId)

  const handleCollect = () => {
    const selectedSubCollection = selectedSubId.subCollections.find(
      (subCollection) => subCollection.id === selectedSubId.selectedId
    );
  
    if (selectedSubCollection && selectedSubCollection.comics.length < 20) {
        dispatch(actions.collectComic(selectedSubId, showData[0]));
    } else {
      if (!alertShown) {
        alert('Cannot add more than 20 comics to the selected subcollection. Give up before Adding more');
        setAlertShown(true); 
      }
    }
  
    navigate(`/marvel-comics/${showData[0].id}`);
  };

  
  const handleGiveUp = () => {
      dispatch(actions.giveUpComic(selectedSubId, showData[0]));
    navigate(`/marvel-comics/${showData[0].id}`);
  };
  
  const [showData, setShowData] = useState(undefined);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        if (!validId.test(id)) {
          return navigate('/Error1');
        } 

        const { data: show } = await axios.get(
          `http://localhost:3000/api/comics/${id}`
        );
        if (show) {
          setShowData(show);
        }
        setLoading(false);
      } catch (e) {
        console.log(e);
        navigate('/Error');
      }
    }
    fetchData();
  }, [id]);

  console.log("showData comic.jsx",showData?showData:"NOPE")
  if (loading) {
    return <h2>Loading....</h2>;
  } else {
    
    const handleClick = () => {
      if (showData) {
      
        navigate(`/marvel-comics/${id}`);
      }
    };
  
    return (
      <>
        <Card
          variant="outlined"
          sx={{
            maxWidth: 550,
            height: 'auto',
            marginLeft: 'auto',
            marginRight: 'auto',
            borderRadius: 5,
            border: '1px solid #1e8678',
            boxShadow: '0 19px 38px rgba(0,0,0,0.30);',
            cursor: 'pointer',
          }}
          onClick={handleClick}
        >
           <dl>
              <dt className="title">Comic ID:</dt>
              {showData && (showData.id || showData[0].id) ? (
                <dd>{showData.id ? showData.id : showData[0].id}</dd>
              ) : (
                <dd>N/A</dd>
              )}
            </dl>
            
            <CardMedia
                sx={{
                  height: '100%',
                  width: '100%',
                }}
                component='img'
                image={
                  showData &&
                  ((showData.images && showData.images[0]) ||
                    (showData[0] && showData[0].images && showData[0].images[0]))
                    ? `${((showData.images && showData.images[0]) || (showData[0] && showData[0].images && showData[0].images[0])).path.replace(/ /g, '_')}.jpg`
                    : noImage
                }
                alt={showData && (showData.title || showData[0].title) ? (showData.title || showData[0].title) : 'Comic Image Alt Text'}
              />

            <dl>
              <dt className="title">Title:</dt>
              {showData && (showData.title || showData[0].title) ? (
                <dd>{showData.title ? showData.title : showData[0].title}</dd>
              ) : (
                <dd>N/A</dd>
              )}
            </dl>

            <dl>
              <dt className="title">Description:</dt>
              <dd>
                {showData &&
                ((showData.description && showData.description) ||
                  (showData[0] &&
                    showData[0].description &&
                    showData[0].description))
                  ? showData.description || showData[0].description
                  : 'N/A'}
              </dd>
            </dl>

            <dl>
              <dt className="title">On Sale Date:</dt>
              {showData && (
                (showData.dates && showData.dates.map) ||
                (showData[0].dates && showData[0].dates.map)
              ) ? (
                ((showData.dates || showData[0].dates).map((date) =>
                  date.type === 'onsaleDate' ? (
                    <dd key={date.date}>{date.date}</dd>
                  ) : null
                )) || null
              ) : (
                <dd>N/A</dd>
              )}
            </dl>

            <dl>
              <dt className="title">Print Price:</dt>
              {showData && (
                (showData.prices && showData.prices.map) ||
                (showData[0].prices && showData[0].prices.map)
              ) ? (
                ((showData.prices || showData[0].prices).map((price) =>
                  price.type === 'printPrice' ? (
                    <dd key={price.price}>{price.price}</dd>
                  ) : null
                )) || null
              ) : (
                <dd>N/A</dd>
              )}
            </dl>
  
          {selectedSubId.selectedId && (
            <>
              {!selectedSubId.subCollections
                .find(
                  (subCollection) =>
                    subCollection.id === selectedSubId.selectedId
                )
                .comics.some((comic) => comic.id === showData[0].id) && (
                <button onClick={handleCollect}> Collect </button>
              )}
  
              {selectedSubId.subCollections
                .find(
                  (subCollection) =>
                    subCollection.id === selectedSubId.selectedId
                )
                .comics.some((comic) => comic.id === showData[0].id) && (
                <button onClick={handleGiveUp}> Give Up </button>
              )}
            </>
          )}
        </Card>
        <Link to="/marvel-comics/page/1">Show all Comics...</Link>
        <br />
        <Link to="/marvel-comics/collections">Show all Collections...</Link>
      </>
    );
  };
}
  export default Comic;