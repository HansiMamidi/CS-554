import React from 'react';
import { Link} from 'react-router-dom';

function Error1() {
  return (
    <div>
      <h2>400:Bad Input</h2>
      <Link to="/marvel-comics/page/1">Show all Comics...</Link>
      <Link to="/marvel-comics/collections">show all Collections...</Link>
    </div>
  );
}

export default Error1;
