import React from 'react';
// import ComicList from './ComicList';
import {Link, useParams} from 'react-router-dom';

function Home(props) {
  console.log("yup")
  return (
    <>
      <Link to='/marvel-comics/page/1'>Show all the Comics...</Link>
    </>
  );
}

export default Home;
