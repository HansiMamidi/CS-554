import {combineReducers} from '@reduxjs/toolkit';
import todoReducer from './todoReducer';
import userReducer from './userReducer';
const rootReducer = combineReducers({
  comics: todoReducer,
  collections: userReducer
});

export default rootReducer;
