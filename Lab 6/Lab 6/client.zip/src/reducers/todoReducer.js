import {v4 as uuid} from 'uuid';
const todoReducer = (state = [], action) => {
  const {type, payload} = action;
  
  switch (type) {
    case 'ALL_COMICS':
      console.log("payload all comics", payload)
      return payload; 
    
    // case 'CREATE_SUBCOLLECTION':
    //   console.log('payload', payload);
    //   return [
    //     ...state,
    //     {
    //       id: uuid(),
    //       name: payload.name,
    //       completed: false
    //     }
    //   ];

    // case 'DELETE_SUBCOLLECTION':
    //   copyState = [...state];
    //   index = copyState.findIndex((x) => x.id === payload.id);
    //   copyState.splice(index, 1);
    //   return [...copyState];

    // case 'SELECT_SUBCOLLECTION':
    //   return state.map((subcollection) => {
    //     if (subcollection.id === payload.id) {
    //       return {
    //         ...subcollection,
    //         completed: true
    //       };
    //     } else return subcollection;
    //   });

    // case 'UNCOMPLETE_TODO':
    //   return state.map((todo) => {
    //     if (todo.id === payload.id) {
    //       return {
    //         ...todo,
    //         completed: false
    //       };
    //     } else return todo;
    //   });

    default:
      return state;
  }
};
export default todoReducer;