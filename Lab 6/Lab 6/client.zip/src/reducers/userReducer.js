import { v4 as uuid } from 'uuid';

const initialState = {
  subCollections: [],
  selectedId: null,
};

const userReducer = (state = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case 'CREATE_SUBCOLLECTION':
      return {
        ...state,
        subCollections: [
          ...(state.subCollections || []),
          {
            id: uuid(),
            name: payload.name,
            comics: [],
            selectedId: uuid(),
          },
        ],
      };

    case 'DELETE_SUBCOLLECTION':
      return {
        ...state,
        subCollections: state.subCollections.filter(
          (subcollection) => subcollection.id !== payload.id
        ),
      };

    case 'SELECT_SUBCOLLECTION':
      return {
        ...state,
        selectedId: payload.id,
      };

      case 'COLLECT_COMIC':
        // console.log('COLLECT_COMIC action dispatched:', payload.id, payload.comic);
        // console.log("state check", state.collections.selectedId)

        const updatedState = {
          ...state,
          subCollections: (state.subCollections || []).map((subCollection) => {
            // console.log("IDS COMPARE",subCollection.id, state.selectedId)
            if (subCollection.id === state.selectedId) {
              // console.log("EQUAL");

              return {
                ...subCollection,
                comics: [...(subCollection.comics || []), payload.comic],
              };
            }
            return subCollection;
          }),
        };

        // console.log('State after update:', updatedState);
        return updatedState;

        case 'GIVEUP_COMIC':
          // console.log('GIVEUP_COMIC action dispatched:', payload.id, payload.comic);
          // console.log("state check", state.selectedId);
        
          const updatedStateGiveUp = {
            ...state,
            subCollections: (state.subCollections || []).map((subCollection) => {
              // console.log("IDS COMPARE", subCollection.id, state.selectedId);
              if (subCollection.id === state.selectedId) {
                // console.log("EQUAL");
                return {
                  ...subCollection,
                  comics: (subCollection.comics || []).filter(
                    (comic) => comic.id !== payload.comic.id
                  ),
                };
              }
              return subCollection;
            }),
          };
        
          // console.log('State after update:', updatedStateGiveUp);
          return updatedStateGiveUp;
        
    case 'GET_ALL_COLLECTED_COMICS':
      const allSubCollections = (state.subCollections || []).find(
        (subcollection) => subcollection.id === payload.id
      );

      return {
        ...state,
        selectedId: payload.id,
        currentSubCollection: allSubCollections,
      };

    default:
      return state;
  }
};

export default userReducer;
